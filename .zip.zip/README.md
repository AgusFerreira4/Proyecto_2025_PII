Nacho:
Yo creo que lo mas dificil fue lograr entender el flujo del programa ya que estabamos hablando de cosas medias abstractas y de mientras teniamos que tener en cuenta los nuevos principios que nos iban enseñando y eso me mareo un poco

Aprendi a como comunicarme eficientemente con mis compañeros

Como comentario sobre el trabajo siento que lo que pedian en las entregas y lo que explicaban que se queria en clase era distinto en algunos casos y eso generaba confusion

------------------------------------------------------------------------------------------------------------------------------------------------

Agustin Ferreira:
En primera parte disfruto la parte de trabajar en equipo que tiene que ver con los desafios de organizacion y comunicacion interna, tener algunos inconvenientes con estos temas me ayudo mucho a buscar nuevas formas o implementar herramientas para comunicarme y resolver problemas de la forma mas eficiente, o al menos eso espero.

Por otro lado el proyecto tiene una propuesta muy buena y muy interesante para encarar, a mi me gusta mucho estar desarrollando esto y tengo muchas ganas de ver su implementacion final, tambien siento que en si el desarrollo del codigo y del flujo del programa fue muy dificl de hacer, no solo porque en el repo las instrucciones aveces no estaban claras o porque pedian cosas a las que nunca nos dieron introduccion(xml), si no porque tambien nos iban enseñando muy sobre la marcha cosas que nos sirven para el proyecto, por ejemplo, algo que fue esencial para nosotros como lo es el patron Singleton en esta entrega, nos lo comentaron recien a 1 o 2 semanas de la entrega.

Lo positivo que le puedo sacar a eso, es que es un desafio total, ya que tenes que ingeniartelas para que el dia de mañana puedas resolver siutaciones similares, el poder ser creativos dentro de lo que se podia y desarrollar nuestra solucion a nuestro modo es una muy buena experiencia, pero aun asi siento que fue demasiada ambiguedad.

Algo que use mucho para poder entender ciertos conceptos y guiarme de flujos de programas parecidos fue videos de youtube y foros de internet.

------------------------------------------------------------------------------------------------------------------------------------------------

Luciano Rodriguez:
Regresar al equipo fue un desafío. Al ver como estaba el estado del diagrama UML tuvimos que enfrentarnos todos a rehacer el sistema para que funcione mejor con ayuda del feedback dado por los profesores. Noté como mis compañeros lograban aplicar bien los distintos patrones de diseño y guías que habíamos aprendido. Debido al parcial de Matemática Discreta, no le dimos el tiempo que merecía el proyecto, pero en poco tiempo se pudo obtener un gran resultado respecto al sistma de clases. 

Lograr ver cómo lo aprendido en clase es aplicado en un contexto real me ha servido de mucho para entender cómo usarlo. Estoy más acostumbrado a que lo que aprendo no se use mucho en lo cotidiano que esta es de las primeraas veces que digo que lo que aprendí en clase me va a servir para el futuro. Quizás noté que los patrones de diseño son entregados muy a último momento, como menciona Agustín. Siento que respecto a las clases, nos dieron todas las herramientas para poder trabajar pero que nos faltan más ejercicios prácticos para poder mejorar. Un equilibrio entre lo teórico y lo práctico es lo que me gustaría ver en esta materia, para que no suceda que a la hora de encarar un proyecto grande se pueda tener mayor facilidad de organización y comprensión de un sistema de manera más practica.

Respecto al proyecto mismo, está bueno, aunque hubieron cosas que fueron ambiguas, como que la clase Usuario era instanciable tambíen, que no se especificaron de antemano y que seguramente le afectó a muchos grupos además del nuestro. 

Supongo que no fue un desafío dificil por falta de herramientas, sino más bien a veces puede llegar a complicarse por falta de experiencia, al menos eso creo yo.

------------------------------------------------------------------------------------------------------------------------------------------------

Gastón Gardil:
Desde mi perspectiva, el proyecto es una forma muy eficaz de ir aplicando lo que vemos en clase y así ir incorporándolo de verdad.  

Lo más complicado para mí fue arrancar el UML desde cero: entender cómo tenía que funcionar cada cosa y qué lógica implementar. Al principio era todo muy abstracto, pero a medida que el diagrama iba tomando forma y empezamos a codear, todo se fue haciendo más claro y un poco más ameno.  

Me gustó mucho trabajar con mis compañeros. Fue una excelente forma de aprender a comunicarnos en equipo, dividir tareas, coordinar horarios y resolver problemas juntos.  

En conclusión, gracias al proyecto estoy consolidando un montón de conceptos que damos en clase, me está enseñando a pensar de manera más estructurada para resolver conflictos y creo que logramos una comunicación súper eficiente dentro del grupo.

------------------------------------------------------------------------------------------------------------------------------------------------

Descripción del proyecto:
Este proyecto consiste en el desarrollo de un CRM (Customer Relationship Management) implementado como un chatbot conversacional. El objetivo es crear un sistema que permita gestionar clientes, sus datos, interacciones (llamadas, reuniones, mensajes, correos), ventas, cotizaciones, etiquetas y reportes, todo a través de una interfaz de chat.
El bot se integra con Discord y permite a los usuarios realizar todas las operaciones del CRM mediante comandos y conversaciones naturales.
